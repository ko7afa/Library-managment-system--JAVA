public class MemberNode {
    String name;
    int id;
    MemberNode next;

    public MemberNode(String name, int  id) {
        this.name = name;
        this.id = id;
        this.next = null;
    }
}
